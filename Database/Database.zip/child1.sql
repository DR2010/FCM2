-- MySQL dump 10.13  Distrib 5.5.21, for Win64 (x86)
--
-- Host: localhost    Database: childcare
-- ------------------------------------------------------
-- Server version	5.5.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `child`
--

DROP TABLE IF EXISTS `child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `child` (
  `UID` bigint(20) NOT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `AddressStreetName` varchar(100) DEFAULT NULL,
  `AddressStreetNumber` varchar(45) DEFAULT NULL,
  `AddressSuburb` varchar(100) DEFAULT NULL,
  `AddressCity` varchar(100) DEFAULT NULL,
  `AddressPostCode` varchar(10) DEFAULT NULL,
  `UserIdCreatedBy` varchar(10) DEFAULT NULL,
  `UserIdUpdatedBy` varchar(10) DEFAULT NULL,
  `CreationDateTime` datetime DEFAULT NULL,
  `UpdateDateTime` datetime DEFAULT NULL,
  `RecordVersion` int(11) DEFAULT NULL,
  `IsVoid` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `IDX_SURNAME` (`Surname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `child`
--

LOCK TABLES `child` WRITE;
/*!40000 ALTER TABLE `child` DISABLE KEYS */;
INSERT INTO `child` VALUES (1,'sdfsdfsadfsda','sdfsdfsadfdf',NULL,NULL,NULL,NULL,NULL,NULL,'DM0001','DM0001','2012-03-03 19:03:48','2012-03-03 19:03:48',1,NULL),(2,'hdfdfvgdsfrg','dgdfgdfgdsfg',NULL,NULL,NULL,NULL,NULL,NULL,'DM0001','DM0001','2012-03-03 19:04:04','2012-03-03 19:04:04',1,NULL),(3,'Daniel','First Child','2012-10-10',NULL,NULL,NULL,NULL,NULL,'DM0001','DM0001','2012-03-03 19:10:29','2012-03-03 19:10:29',1,'N'),(4,'Katia','Child 2','2010-10-10',NULL,NULL,NULL,NULL,NULL,'DM0001','DM0001','2012-03-03 19:11:13','2012-03-03 19:11:13',1,'N'),(5,'Daniel 2','Sur 2','2000-10-10',NULL,NULL,NULL,NULL,NULL,'DM0001','DM0001','2012-03-03 19:21:16','2012-03-03 19:21:16',1,'N'),(6,'Arthur C','Surname Arthur','2000-12-11',NULL,NULL,NULL,NULL,NULL,'DM0001','DM0001','2012-03-03 19:41:45','2012-03-03 19:41:45',1,'N'),(7,'Arthur ','Testw','1998-10-20','teste',NULL,NULL,NULL,NULL,'child','child','2012-03-04 23:04:37','2012-03-04 23:04:37',1,'N');
/*!40000 ALTER TABLE `child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `childroom`
--

DROP TABLE IF EXISTS `childroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `childroom` (
  `UID` bigint(20) NOT NULL,
  `FKChildUID` bigint(20) DEFAULT NULL,
  `FKRoomUID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_ChildRoomIDX1` (`FKChildUID`),
  KEY `FKN_ChildRoomIDX2` (`FKRoomUID`),
  CONSTRAINT `FKN_ChildRoomIDX1` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_ChildRoomIDX2` FOREIGN KEY (`FKRoomUID`) REFERENCES `room` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `childroom`
--

LOCK TABLES `childroom` WRITE;
/*!40000 ALTER TABLE `childroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `childroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incident`
--

DROP TABLE IF EXISTS `incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incident` (
  `UID` bigint(20) NOT NULL,
  `IncidentDate` date DEFAULT NULL,
  `ReportDate` date DEFAULT NULL,
  `TimeOfIncident` varchar(45) DEFAULT NULL,
  `Description` text,
  `WasAmbulanceCalled` char(1) DEFAULT NULL,
  `WasAbleToContactParent` char(1) DEFAULT NULL,
  `NameOfPersonContacted` varchar(50) DEFAULT NULL,
  `PhoneNumberUsed` varchar(50) DEFAULT NULL,
  `TimeOfCall` varchar(45) DEFAULT NULL,
  `FKWorkerTeamLeaderUID` bigint(20) DEFAULT NULL,
  `FKWorkerReportingOfficerUID` bigint(20) DEFAULT NULL,
  `FKChildUID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_TeamLeader` (`FKWorkerTeamLeaderUID`),
  KEY `FKN_ReportingOfficer` (`FKWorkerReportingOfficerUID`),
  KEY `FKN_Child` (`FKChildUID`),
  CONSTRAINT `FKN_Child` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_ReportingOfficer` FOREIGN KEY (`FKWorkerReportingOfficerUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_TeamLeader` FOREIGN KEY (`FKWorkerTeamLeaderUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incident`
--

LOCK TABLES `incident` WRITE;
/*!40000 ALTER TABLE `incident` DISABLE KEYS */;
/*!40000 ALTER TABLE `incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `UID` bigint(20) NOT NULL,
  `Date` date DEFAULT NULL,
  `MonthYear` varchar(45) DEFAULT NULL,
  `Summary` varchar(255) DEFAULT NULL,
  `Comments` longtext,
  `FKChildUID` bigint(20) DEFAULT NULL,
  `FKWorkerReportingOfficerUID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_ReportChildIDX1` (`FKChildUID`),
  KEY `FKN_ReportingOfficerIDX2` (`FKWorkerReportingOfficerUID`),
  CONSTRAINT `FKN_ReportChildIDX1` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_ReportingOfficerIDX2` FOREIGN KEY (`FKWorkerReportingOfficerUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportmetadata`
--

DROP TABLE IF EXISTS `reportmetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportmetadata` (
  `UID` bigint(20) NOT NULL,
  `RecordType` varchar(2) NOT NULL,
  `FieldCode` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `ClientType` varchar(10) DEFAULT NULL,
  `ClientUID` bigint(20) DEFAULT NULL,
  `InformationType` varchar(10) NOT NULL,
  `TableNameX` varchar(50) DEFAULT NULL,
  `FieldNameX` varchar(50) DEFAULT NULL,
  `FilePathX` varchar(50) DEFAULT NULL,
  `FileNameX` varchar(50) DEFAULT NULL,
  `ConditionX` varchar(200) DEFAULT NULL,
  `CompareWith` varchar(100) DEFAULT NULL,
  `Enabled` char(1) DEFAULT NULL,
  `UseAsLabel` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportmetadata`
--

LOCK TABLES `reportmetadata` WRITE;
/*!40000 ALTER TABLE `reportmetadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportmetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `UID` bigint(20) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `AgeGroupName` varchar(45) DEFAULT NULL,
  `AgeGroupCode` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (0,'red','toddler','10');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker`
--

DROP TABLE IF EXISTS `worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker` (
  `UID` bigint(20) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `Surname` varchar(50) DEFAULT NULL,
  `WLVL_Level` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker`
--

LOCK TABLES `worker` WRITE;
/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` VALUES (0,'Katia','Machado','LVL1');
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workerroom`
--

DROP TABLE IF EXISTS `workerroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workerroom` (
  `UID` bigint(20) NOT NULL,
  `FKWorkerUID` bigint(20) DEFAULT NULL,
  `FKRoomUID` bigint(20) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `IsActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_Worker` (`FKWorkerUID`),
  KEY `FKN_Room` (`FKRoomUID`),
  CONSTRAINT `FKN_Room` FOREIGN KEY (`FKRoomUID`) REFERENCES `room` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_Worker` FOREIGN KEY (`FKWorkerUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workerroom`
--

LOCK TABLES `workerroom` WRITE;
/*!40000 ALTER TABLE `workerroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `workerroom` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-25  9:08:31
