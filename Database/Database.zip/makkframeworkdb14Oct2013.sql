-- MySQL dump 10.13  Distrib 5.5.25, for Win64 (x86)
--
-- Host: localhost    Database: makkframeworkdb
-- ------------------------------------------------------
-- Server version	5.5.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `processrequest`
--

DROP TABLE IF EXISTS `processrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `processrequest` (
  `UID` bigint(20) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `FKClientUID` bigint(20) DEFAULT NULL,
  `Type` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `WhenToProcess` varchar(50) NOT NULL,
  `CreationDateTime` datetime NOT NULL,
  `PlannedDateTime` datetime NOT NULL,
  `StatusDateTime` datetime NOT NULL,
  `RequestedByUser` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processrequest`
--

LOCK TABLES `processrequest` WRITE;
/*!40000 ALTER TABLE `processrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `processrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processrequestarguments`
--

DROP TABLE IF EXISTS `processrequestarguments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `processrequestarguments` (
  `FKRequestUID` bigint(20) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `ValueType` varchar(50) DEFAULT NULL,
  `Value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`FKRequestUID`,`Code`),
  KEY `fk_processrequest` (`FKRequestUID`),
  KEY `fk_processrequest1` (`FKRequestUID`),
  CONSTRAINT `fk_processrequest1` FOREIGN KEY (`FKRequestUID`) REFERENCES `processrequest` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='	';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processrequestarguments`
--

LOCK TABLES `processrequestarguments` WRITE;
/*!40000 ALTER TABLE `processrequestarguments` DISABLE KEYS */;
/*!40000 ALTER TABLE `processrequestarguments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processrequestresults`
--

DROP TABLE IF EXISTS `processrequestresults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `processrequestresults` (
  `FKRequestUID` bigint(20) NOT NULL,
  `SequenceNumber` bigint(20) NOT NULL,
  `FKClientUID` bigint(20) DEFAULT NULL,
  `Results` varchar(2000) NOT NULL,
  `Type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`FKRequestUID`,`SequenceNumber`),
  KEY `fk_processrequest` (`FKRequestUID`),
  CONSTRAINT `fk_processrequest` FOREIGN KEY (`FKRequestUID`) REFERENCES `processrequest` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processrequestresults`
--

LOCK TABLES `processrequestresults` WRITE;
/*!40000 ALTER TABLE `processrequestresults` DISABLE KEYS */;
/*!40000 ALTER TABLE `processrequestresults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rdcodetype`
--

DROP TABLE IF EXISTS `rdcodetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rdcodetype` (
  `CodeType` varchar(20) NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `ShortCodeType` char(3) DEFAULT NULL,
  PRIMARY KEY (`CodeType`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rdcodetype`
--

LOCK TABLES `rdcodetype` WRITE;
/*!40000 ALTER TABLE `rdcodetype` DISABLE KEYS */;
INSERT INTO `rdcodetype` VALUES ('LEAR','Linking to Early Years',NULL),('LESI','LEAR Sub Item',NULL),('PRAC','Practices',NULL),('PRIN','Principle',NULL),('ROLE','Worker Role','WRL'),('ROOM','Room Code','RCD'),('ROOMCD','Room Code','STS'),('STATE','Australian States','STA'),('TEST','test','GGH'),('WLVL','Worker Level','WLV');
/*!40000 ALTER TABLE `rdcodetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rdcodevalue`
--

DROP TABLE IF EXISTS `rdcodevalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rdcodevalue` (
  `FKCodeType` varchar(20) NOT NULL,
  `ID` varchar(20) NOT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Abbreviation` varchar(10) DEFAULT NULL,
  `ValueExtended` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`FKCodeType`,`ID`),
  KEY `FK_CodeValue_CodeType` (`FKCodeType`),
  CONSTRAINT `FK_CodeValue_CodeType` FOREIGN KEY (`FKCodeType`) REFERENCES `rdcodetype` (`CodeType`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rdcodevalue`
--

LOCK TABLES `rdcodevalue` WRITE;
/*!40000 ALTER TABLE `rdcodevalue` DISABLE KEYS */;
INSERT INTO `rdcodevalue` VALUES ('LEAR','LO1','Children Have A Strong Sense of Identity',NULL,'../../TextPages/LO1.html'),('LEAR','LO2','Children Are Connected With & Contribute To Their World',NULL,'../../TextPages/LO2.html'),('LEAR','LO3','Children Have a Strong Sense of Well Being',NULL,'../../TextPages/LO3.html'),('LEAR','LO4','Children Are Confident & Involved Learners',NULL,'../../TextPages/LO4.html'),('LEAR','LO5','Children Are Effective Communicators',NULL,'../../TextPages/LO5.html'),('LESI','LSI11','Children feel safe, secure and supported','','../../TextPages/LSI11.html'),('LESI','LSI12','Children develop their autonomy, inter-dependence, resilience and sense of agency','','../../TextPages/LSI12.html'),('LESI','LSI13','Children develop knowledgeable and confident self-identities.','','../../TextPages/LSI13.html'),('LESI','LSI14','Children learn no interact in relation to others with care, empathy and respect.','','../../TextPages/LSI14.html'),('LESI','LSI21','Children develop a sense of belonging to groups & communities and an understanding of the reciprocal rights & responsibilities necessary for active communication.',NULL,'../../TextPages/LSI21.html'),('LESI','LSI22','Children respond to diversity with respect.',NULL,'../../TextPages/LSI22.html'),('LESI','LSI23','Children become aware of fairness',NULL,'../../TextPages/LSI23.html'),('LESI','LSI24','Children become socially responsible and show respect for the environment',NULL,'../../TextPages/LSI24.html'),('LESI','LSI31','Children become strong in their social and emotion wellbeing',NULL,'../../TextPages/LSI31.html'),('LESI','LSI32','Children take increasing responsibility for their own health and physical wellbeing.',NULL,'../../TextPages/LSI32.html'),('LESI','LSI41','Children develop dispositions for learning such as curiosity, cooperation, confidence, creativity, commitment, enthusiasm, persistence, imagination & reflexivity.',NULL,'../../TextPages/LSI41.html'),('LESI','LSI42','Children develop a range of skills & processes such as problem solving, enquiry, experimentation, hypothesizing, researching & investigating.',NULL,'../../TextPages/LSI42.html'),('LESI','LSI43','Children transfer & adapt what they learned from one context to another.',NULL,'../../TextPages/LSI43.html'),('LESI','LSI44','Children resource their own learning through connecting with people, place, technologies and natural and processed materials.',NULL,'../../TextPages/LSI44.html'),('LESI','LSI51','Children interact verbally & non-verbally with others for a range of purposes.',NULL,'../../TextPages/LSI51.html'),('LESI','LSI52','Children express ideas and make meaning using a range of media.',NULL,'../../TextPages/LSI52.html'),('LESI','LSI53','Children express ideas and make meaning using a range of media.',NULL,'../../TextPages/LSI53.html'),('LESI','LSI54','Children begin to understand how symbols and pattern systems work.',NULL,'../../TextPages/LSI54.html'),('LESI','LSI55','Children use information and communication technologies to access information, investigate ideas and represent their thinking.',NULL,'../../TextPages/LSI55.html'),('PRAC','PE01','Holistic Approaches',NULL,NULL),('PRAC','PE02','Responsiveness to Children.',NULL,NULL),('PRAC','PE03','Learning Through Play',NULL,NULL),('PRAC','PE04','Intentional teaching.',NULL,NULL),('PRAC','PE05','Learning Environments.',NULL,NULL),('PRAC','PE06','Cultural Competence.',NULL,NULL),('PRAC','PE07','Continuity of Learning & Transitions.',NULL,NULL),('PRAC','PE08','Assessment for Learning.',NULL,NULL),('PRIN','PR01','Secure, respectful and reciprocal relations.',NULL,NULL),('PRIN','PR02','Partnerships.',NULL,NULL),('PRIN','PR03','High expectations and Equality.',NULL,NULL),('PRIN','PR04','Respect for diversity.',NULL,NULL),('PRIN','PR05','Ongoing Learning and Reflective Practice.',NULL,NULL),('ROLE','ADMIN','Administration',NULL,NULL),('ROLE','ROLE3','Role 3',NULL,NULL),('ROLE','ROLE4','Role 4',NULL,NULL),('ROLE','ROLE5','Role 5',NULL,NULL),('ROLE','WORKER','Worker',NULL,NULL),('ROOM','BLUE','Blue Room',NULL,NULL),('ROOM','RED','Red Room',NULL,NULL),('ROOM','YELLOW','Yellow Room',NULL,NULL),('STATE','ACT','Australian Capital Territory',NULL,NULL),('STATE','NSW','New South Wales',NULL,NULL),('STATE','NT','Northern Territory',NULL,NULL),('STATE','QLD','Queensland',NULL,NULL),('STATE','SA','South Australia',NULL,NULL),('STATE','TAS','Tasmania',NULL,NULL),('STATE','WA','Western Australia',NULL,NULL),('WLVL','LEVEL1','Level 1','LVL1',NULL),('WLVL','LEVEL2','Level 2','LVL2','');
/*!40000 ALTER TABLE `rdcodevalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rdrelatedcode`
--

DROP TABLE IF EXISTS `rdrelatedcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rdrelatedcode` (
  `RelatedCodeID` varchar(20) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `FKCodeTypeFrom` varchar(20) NOT NULL,
  `FKCodeTypeTo` varchar(20) NOT NULL,
  PRIMARY KEY (`RelatedCodeID`),
  KEY `fk_relatedcode_codetype1` (`FKCodeTypeFrom`),
  KEY `fk_relatedcode_codetype2` (`FKCodeTypeTo`),
  CONSTRAINT `fk_relatedcode_codetype1` FOREIGN KEY (`FKCodeTypeFrom`) REFERENCES `rdcodetype` (`CodeType`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_relatedcode_codetype2` FOREIGN KEY (`FKCodeTypeTo`) REFERENCES `rdcodetype` (`CodeType`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rdrelatedcode`
--

LOCK TABLES `rdrelatedcode` WRITE;
/*!40000 ALTER TABLE `rdrelatedcode` DISABLE KEYS */;
INSERT INTO `rdrelatedcode` VALUES ('LEARLESI','Learning Outcome to Learning Outcome Item','LEAR','LESI');
/*!40000 ALTER TABLE `rdrelatedcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rdrelatedcodevalue`
--

DROP TABLE IF EXISTS `rdrelatedcodevalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rdrelatedcodevalue` (
  `FKCodeTypeFrom` varchar(20) NOT NULL,
  `FKCodeValueFrom` varchar(20) NOT NULL,
  `FKCodeTypeTo` varchar(20) NOT NULL,
  `FKCodeValueTo` varchar(20) NOT NULL,
  `FKRelatedCodeID` varchar(20) NOT NULL,
  PRIMARY KEY (`FKCodeTypeFrom`,`FKCodeValueFrom`,`FKCodeTypeTo`,`FKCodeValueTo`,`FKRelatedCodeID`),
  KEY `FK_Destination` (`FKCodeTypeTo`,`FKCodeValueTo`),
  KEY `fk_relatedcodevalue_relatedcode1` (`FKRelatedCodeID`),
  CONSTRAINT `FK_Destination` FOREIGN KEY (`FKCodeTypeTo`, `FKCodeValueTo`) REFERENCES `rdcodevalue` (`FKCodeType`, `ID`),
  CONSTRAINT `fk_relatedcodevalue_relatedcode1` FOREIGN KEY (`FKRelatedCodeID`) REFERENCES `rdrelatedcode` (`RelatedCodeID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Source` FOREIGN KEY (`FKCodeTypeFrom`, `FKCodeValueFrom`) REFERENCES `rdcodevalue` (`FKCodeType`, `ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rdrelatedcodevalue`
--

LOCK TABLES `rdrelatedcodevalue` WRITE;
/*!40000 ALTER TABLE `rdrelatedcodevalue` DISABLE KEYS */;
INSERT INTO `rdrelatedcodevalue` VALUES ('LEAR','LO1','LESI','LSI11','LEARLESI'),('LEAR','LO1','LESI','LSI12','LEARLESI'),('LEAR','LO1','LESI','LSI13','LEARLESI'),('LEAR','LO1','LESI','LSI14','LEARLESI'),('LEAR','LO2','LESI','LSI21','LEARLESI'),('LEAR','LO2','LESI','LSI22','LEARLESI'),('LEAR','LO2','LESI','LSI23','LEARLESI'),('LEAR','LO2','LESI','LSI24','LEARLESI'),('LEAR','LO3','LESI','LSI31','LEARLESI'),('LEAR','LO3','LESI','LSI32','LEARLESI'),('LEAR','LO4','LESI','LSI41','LEARLESI'),('LEAR','LO4','LESI','LSI42','LEARLESI'),('LEAR','LO4','LESI','LSI43','LEARLESI'),('LEAR','LO4','LESI','LSI44','LEARLESI'),('LEAR','LO5','LESI','LSI51','LEARLESI'),('LEAR','LO5','LESI','LSI52','LEARLESI'),('LEAR','LO5','LESI','LSI53','LEARLESI');
/*!40000 ALTER TABLE `rdrelatedcodevalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securityrole`
--

DROP TABLE IF EXISTS `securityrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securityrole` (
  `Role` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  PRIMARY KEY (`Role`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securityrole`
--

LOCK TABLES `securityrole` WRITE;
/*!40000 ALTER TABLE `securityrole` DISABLE KEYS */;
INSERT INTO `securityrole` VALUES ('ADMIN','Administrator'),('ROLE3','ROLE3'),('ROLE4','ROLE4'),('ROLE5','ROLE5'),('WORKER','Child Care Worker');
/*!40000 ALTER TABLE `securityrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securityrolescreen`
--

DROP TABLE IF EXISTS `securityrolescreen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securityrolescreen` (
  `FKRoleCode` varchar(50) NOT NULL,
  `FKScreenCode` varchar(20) NOT NULL,
  PRIMARY KEY (`FKRoleCode`),
  KEY `FK_SecurityUserRole_SecurityRole` (`FKRoleCode`),
  CONSTRAINT `FK_SecurityRole` FOREIGN KEY (`FKRoleCode`) REFERENCES `securityrole` (`Role`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securityrolescreen`
--

LOCK TABLES `securityrolescreen` WRITE;
/*!40000 ALTER TABLE `securityrolescreen` DISABLE KEYS */;
/*!40000 ALTER TABLE `securityrolescreen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securityuser`
--

DROP TABLE IF EXISTS `securityuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securityuser` (
  `UserID` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Salt` varchar(50) NOT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `LogonAttempts` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securityuser`
--

LOCK TABLES `securityuser` WRITE;
/*!40000 ALTER TABLE `securityuser` DISABLE KEYS */;
INSERT INTO `securityuser` VALUES ('Arthur','113','16','Arthur',0),('CHILD','163','19','Daniel 1',2),('daniel','110','21','daniel',0),('dm0101','113','22','daniel',0),('katia','86','23','Katia',0),('Manuel','113','12','Manuel',0);
/*!40000 ALTER TABLE `securityuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securityuserrole`
--

DROP TABLE IF EXISTS `securityuserrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securityuserrole` (
  `UniqueID` int(11) NOT NULL,
  `FK_UserID` varchar(50) NOT NULL,
  `FK_Role` varchar(50) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `IsActive` char(1) DEFAULT NULL,
  `IsVoid` char(1) DEFAULT NULL,
  PRIMARY KEY (`UniqueID`),
  KEY `FK_FCMUserRole_FCMRole` (`FK_Role`),
  KEY `FK_FCMUserRole_FCMUser` (`FK_UserID`),
  CONSTRAINT `FK_FCMUserRole_FCMRole` FOREIGN KEY (`FK_Role`) REFERENCES `securityrole` (`Role`),
  CONSTRAINT `FK_FCMUserRole_FCMUser` FOREIGN KEY (`FK_UserID`) REFERENCES `securityuser` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securityuserrole`
--

LOCK TABLES `securityuserrole` WRITE;
/*!40000 ALTER TABLE `securityuserrole` DISABLE KEYS */;
INSERT INTO `securityuserrole` VALUES (1,'CHILD','ADMIN','2012-02-19','2012-12-31','Y','N'),(2,'CHILD','WORKER','2012-04-09','9999-12-31','Y','N'),(6,'CHILD','ROLE4','2012-04-09','9999-12-31','Y','N'),(7,'katia','ADMIN','2012-04-09','9999-12-31','Y','N'),(8,'katia','WORKER','2012-04-09','9999-12-31','Y','N'),(11,'Manuel','ADMIN','2012-04-27','9999-12-31','Y','N'),(12,'daniel','ADMIN','2012-07-16','9999-12-31','Y','N');
/*!40000 ALTER TABLE `securityuserrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usersettings`
--

DROP TABLE IF EXISTS `usersettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usersettings` (
  `FKUserID` varchar(50) NOT NULL,
  `FKScreenCode` varchar(50) NOT NULL,
  `FKControlCode` varchar(50) NOT NULL,
  `FKPropertyCode` varchar(50) NOT NULL,
  `Value` char(10) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`FKUserID`,`FKScreenCode`,`FKControlCode`,`FKPropertyCode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usersettings`
--

LOCK TABLES `usersettings` WRITE;
/*!40000 ALTER TABLE `usersettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `usersettings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-10-14 21:57:08
