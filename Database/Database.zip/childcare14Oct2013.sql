-- MySQL dump 10.13  Distrib 5.5.25, for Win64 (x86)
--
-- Host: localhost    Database: childcare
-- ------------------------------------------------------
-- Server version	5.5.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `child`
--

DROP TABLE IF EXISTS `child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `child` (
  `UID` bigint(20) NOT NULL,
  `CurrentRoom` bigint(20) DEFAULT NULL COMMENT 'This is denormalised from ChildRoom table. It contains the current room where a child is placed.',
  `FirstName` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `AddressStreetName` varchar(100) DEFAULT NULL,
  `AddressStreetNumber` varchar(45) DEFAULT NULL,
  `AddressSuburb` varchar(100) DEFAULT NULL,
  `AddressCity` varchar(100) DEFAULT NULL,
  `AddressPostCode` varchar(10) DEFAULT NULL,
  `UserIdCreatedBy` varchar(10) DEFAULT NULL,
  `UserIdUpdatedBy` varchar(10) DEFAULT NULL,
  `CreationDateTime` datetime DEFAULT NULL,
  `UpdateDateTime` datetime DEFAULT NULL,
  `RecordVersion` int(11) DEFAULT NULL,
  `IsVoid` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `IDX_SURNAME` (`Surname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `child`
--

LOCK TABLES `child` WRITE;
/*!40000 ALTER TABLE `child` DISABLE KEYS */;
INSERT INTO `child` VALUES (1,1,'Manuel','da Silva','0001-01-01',NULL,NULL,NULL,NULL,NULL,'child','child','2012-04-29 17:58:37','2012-04-29 17:58:37',1,'N'),(2,2,'Joana','de Souza','2001-10-21',NULL,NULL,NULL,NULL,NULL,'child','child','2012-04-29 17:58:54','2012-04-29 17:58:54',1,'N'),(3,3,'Pokemon','Souza','2001-12-10',NULL,NULL,NULL,NULL,NULL,'child','child','2012-04-29 17:59:22','2012-04-29 17:59:22',1,'N'),(4,4,'Andre','Mac','2002-02-23',NULL,NULL,NULL,NULL,NULL,'child','child','2012-04-29 18:12:40','2012-04-29 18:12:40',1,'N'),(5,5,'Yan','Surm','2010-02-10',NULL,NULL,NULL,NULL,NULL,'child','child','2012-04-29 18:14:02','2012-04-29 18:14:02',1,'N'),(6,1,'Teste Name','Teste Surname','2012-10-10',NULL,NULL,NULL,NULL,NULL,'katia','katia','2012-08-12 12:13:27','2012-08-12 12:13:27',1,'N');
/*!40000 ALTER TABLE `child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `childroom`
--

DROP TABLE IF EXISTS `childroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `childroom` (
  `UID` bigint(20) NOT NULL,
  `FKChildUID` bigint(20) DEFAULT NULL,
  `FKRoomUID` bigint(20) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `UserIdCreatedBy` varchar(10) DEFAULT NULL,
  `UserIdUpdatedBy` varchar(10) DEFAULT NULL,
  `CreationDateTime` datetime DEFAULT NULL,
  `UpdateDateTime` datetime DEFAULT NULL,
  `RecordVersion` int(11) DEFAULT NULL,
  `IsVoid` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_ChildRoomIDX1` (`FKChildUID`),
  KEY `FKN_ChildRoomIDX2` (`FKRoomUID`),
  CONSTRAINT `FKN_ChildRoomIDX1` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_ChildRoomIDX2` FOREIGN KEY (`FKRoomUID`) REFERENCES `room` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `childroom`
--

LOCK TABLES `childroom` WRITE;
/*!40000 ALTER TABLE `childroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `childroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incident`
--

DROP TABLE IF EXISTS `incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incident` (
  `UID` bigint(20) NOT NULL,
  `IncidentDate` date DEFAULT NULL,
  `ReportDate` date DEFAULT NULL,
  `TimeOfIncident` varchar(45) DEFAULT NULL,
  `Description` text,
  `WasAmbulanceCalled` char(1) DEFAULT NULL,
  `WasAbleToContactParent` char(1) DEFAULT NULL,
  `NameOfPersonContacted` varchar(50) DEFAULT NULL,
  `PhoneNumberUsed` varchar(50) DEFAULT NULL,
  `TimeOfCall` varchar(45) DEFAULT NULL,
  `FKWorkerTeamLeaderUID` bigint(20) DEFAULT NULL,
  `FKWorkerReportingOfficerUID` bigint(20) DEFAULT NULL,
  `FKChildUID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_TeamLeader` (`FKWorkerTeamLeaderUID`),
  KEY `FKN_ReportingOfficer` (`FKWorkerReportingOfficerUID`),
  KEY `FKN_Child` (`FKChildUID`),
  CONSTRAINT `FKN_Child` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_ReportingOfficer` FOREIGN KEY (`FKWorkerReportingOfficerUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_TeamLeader` FOREIGN KEY (`FKWorkerTeamLeaderUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incident`
--

LOCK TABLES `incident` WRITE;
/*!40000 ALTER TABLE `incident` DISABLE KEYS */;
/*!40000 ALTER TABLE `incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learningstory`
--

DROP TABLE IF EXISTS `learningstory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `learningstory` (
  `UID` bigint(20) NOT NULL,
  `FKChildUID` bigint(20) DEFAULT NULL,
  `FKEducatorUID` bigint(20) DEFAULT NULL,
  `FKRoomCode` varchar(10) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Story` longtext,
  `AnalysisOfLearning` longtext,
  `ExtensionOfLearning` longtext,
  `ParentsComments` longtext,
  `UserIdCreatedBy` varchar(10) DEFAULT NULL,
  `UserIdUpdatedBy` varchar(10) DEFAULT NULL,
  `CreationDateTime` datetime DEFAULT NULL,
  `UpdateDateTime` datetime DEFAULT NULL,
  `RecordVersion` int(11) DEFAULT NULL,
  `IsVoid` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKchildUID` (`FKChildUID`),
  KEY `FKeducatorUID` (`FKEducatorUID`),
  CONSTRAINT `FKchildUID` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKeducatorUID` FOREIGN KEY (`FKEducatorUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learningstory`
--

LOCK TABLES `learningstory` WRITE;
/*!40000 ALTER TABLE `learningstory` DISABLE KEYS */;
INSERT INTO `learningstory` VALUES (1,1,3,'1','0001-01-01','dsdsfds','sdfds','sfsf','sdssf','child','child','2012-04-29 18:47:42','2012-04-29 18:47:42',1,'N'),(2,1,5,'5','2011-02-20','The learning story the sinadf iasdfgbadssdgddddddddddd','analysis of learjniong','enxanae ta of learnimg','parents comments is now testing','child','child','2012-04-29 18:48:41','2012-04-29 18:48:41',1,'N');
/*!40000 ALTER TABLE `learningstory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learningstoryitem`
--

DROP TABLE IF EXISTS `learningstoryitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `learningstoryitem` (
  `UID` bigint(20) NOT NULL,
  `FKLearningStoryUID` bigint(20) DEFAULT NULL,
  `FKCodeType` varchar(10) DEFAULT NULL,
  `FKCodeValue` varchar(10) DEFAULT NULL COMMENT 'The subtypes are Principle, Practice, Outcome Learning 1, OL2, OL3, OL4, OL5. The subtype was introduced to handle the learning outcomes since it has further breakdown in OL1, OL2 etc. The others, Principle and Practice are being duplicated. Same type, same subtype.',
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='The records are items related to learning stories. For insta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learningstoryitem`
--

LOCK TABLES `learningstoryitem` WRITE;
/*!40000 ALTER TABLE `learningstoryitem` DISABLE KEYS */;
INSERT INTO `learningstoryitem` VALUES (1,52,'LESI','LSI11'),(2,52,'LESI','LSI13'),(3,52,'LESI','LSI14'),(4,52,'LESI','LSI21'),(5,52,'LESI','LSI22'),(6,52,'LESI','LSI23'),(7,52,'LESI','LSI31'),(8,52,'LESI','LSI32'),(9,52,'LESI','LSI41'),(10,52,'LESI','LSI42'),(11,52,'LESI','LSI44'),(12,52,'LESI','LSI52'),(13,52,'LESI','LSI53'),(14,52,'PRAC','PE01'),(15,52,'PRAC','PE03'),(16,52,'PRAC','PE04'),(17,52,'PRAC','PE07'),(18,52,'PRIN','PR03'),(19,52,'PRIN','PR04'),(20,52,'PRIN','PR05'),(33,54,'LESI','LSI11'),(34,54,'LESI','LSI13'),(35,54,'LESI','LSI23'),(36,54,'LESI','LSI24'),(37,54,'LESI','LSI32'),(38,54,'LESI','LSI41'),(39,54,'LESI','LSI42'),(40,54,'LESI','LSI52'),(41,54,'LESI','LSI53'),(42,54,'PRAC','PE01'),(43,54,'PRAC','PE02'),(44,54,'PRAC','PE03'),(45,54,'PRAC','PE06'),(46,54,'PRAC','PE07'),(47,54,'PRAC','PE08'),(48,54,'PRIN','PR01'),(49,54,'PRIN','PR02'),(50,54,'PRIN','PR04'),(51,55,'LESI','LSI11'),(52,55,'LESI','LSI12'),(53,55,'LESI','LSI13'),(54,55,'LESI','LSI22'),(55,55,'LESI','LSI23'),(56,55,'LESI','LSI31'),(57,55,'LESI','LSI43'),(58,55,'LESI','LSI44'),(59,55,'LESI','LSI52'),(60,55,'LESI','LSI53'),(61,55,'PRAC','PE05'),(62,55,'PRAC','PE06'),(63,55,'PRAC','PE07'),(64,55,'PRAC','PE08'),(65,55,'PRIN','PR02'),(66,55,'PRIN','PR03'),(67,55,'PRIN','PR04'),(68,53,'LESI','LSI11'),(69,53,'LESI','LSI12'),(70,53,'LESI','LSI13'),(71,53,'LESI','LSI14'),(72,53,'LESI','LSI21'),(73,53,'LESI','LSI22'),(74,53,'LESI','LSI23'),(75,53,'LESI','LSI24'),(76,53,'LESI','LSI31'),(77,53,'LESI','LSI32'),(78,53,'LESI','LSI41'),(79,53,'LESI','LSI42'),(80,53,'LESI','LSI43'),(81,53,'LESI','LSI44'),(82,53,'LESI','LSI51'),(83,53,'LESI','LSI52'),(84,53,'LESI','LSI53'),(85,53,'PRAC','PE01'),(86,53,'PRAC','PE02'),(87,53,'PRAC','PE03'),(88,53,'PRAC','PE04'),(89,53,'PRAC','PE05'),(90,53,'PRAC','PE06'),(91,53,'PRAC','PE07'),(92,53,'PRAC','PE08'),(93,53,'PRIN','PR01'),(94,53,'PRIN','PR02'),(95,53,'PRIN','PR03'),(96,53,'PRIN','PR04'),(97,53,'PRIN','PR05'),(98,1,'LESI','LSI11'),(99,1,'LESI','LSI14'),(100,1,'LESI','LSI21'),(101,1,'LESI','LSI24'),(102,1,'LESI','LSI31'),(103,1,'LESI','LSI32'),(104,1,'LESI','LSI41'),(105,1,'LESI','LSI44'),(106,1,'LESI','LSI51'),(107,1,'LESI','LSI53'),(108,1,'PRAC','PE01'),(109,1,'PRAC','PE03'),(110,1,'PRAC','PE04'),(111,1,'PRAC','PE05'),(112,1,'PRAC','PE08'),(113,1,'PRIN','PR01'),(114,1,'PRIN','PR05'),(115,56,'LESI','LSI11'),(116,56,'LESI','LSI13'),(117,56,'LESI','LSI21'),(118,56,'LESI','LSI22'),(119,56,'LESI','LSI32'),(120,56,'LESI','LSI41'),(121,56,'LESI','LSI42'),(122,56,'LESI','LSI52'),(123,56,'LESI','LSI53'),(124,56,'PRAC','PE01'),(125,56,'PRAC','PE08'),(126,56,'PRIN','PR04'),(127,56,'PRIN','PR05'),(128,2,'LESI','LSI12'),(129,2,'LESI','LSI44'),(130,2,'LESI','LSI51'),(131,2,'LESI','LSI52'),(132,2,'PRAC','PE03'),(133,2,'PRAC','PE04'),(134,2,'PRAC','PE06'),(135,2,'PRIN','PR04'),(136,2,'PRIN','PR05');
/*!40000 ALTER TABLE `learningstoryitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo` (
  `UID` bigint(20) NOT NULL,
  `FKChildUID` bigint(20) DEFAULT NULL,
  `Location` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FK_ChildUID` (`FKChildUID`),
  CONSTRAINT `FK_ChildUID` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Photo of the child care children';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `UID` bigint(20) NOT NULL,
  `Date` date DEFAULT NULL,
  `MonthYear` varchar(45) DEFAULT NULL,
  `Summary` varchar(255) DEFAULT NULL,
  `Comments` longtext,
  `FKChildUID` bigint(20) DEFAULT NULL,
  `FKWorkerReportingOfficerUID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_ReportChildIDX1` (`FKChildUID`),
  KEY `FKN_ReportingOfficerIDX2` (`FKWorkerReportingOfficerUID`),
  CONSTRAINT `FKN_ReportChildIDX1` FOREIGN KEY (`FKChildUID`) REFERENCES `child` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_ReportingOfficerIDX2` FOREIGN KEY (`FKWorkerReportingOfficerUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportmetadata`
--

DROP TABLE IF EXISTS `reportmetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportmetadata` (
  `UID` bigint(20) NOT NULL,
  `RecordType` varchar(2) NOT NULL,
  `FieldCode` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `ClientType` varchar(10) DEFAULT NULL,
  `ClientUID` bigint(20) DEFAULT NULL,
  `InformationType` varchar(10) NOT NULL,
  `TableNameX` varchar(50) DEFAULT NULL,
  `FieldNameX` varchar(50) DEFAULT NULL,
  `FilePathX` varchar(50) DEFAULT NULL,
  `FileNameX` varchar(50) DEFAULT NULL,
  `ConditionX` varchar(200) DEFAULT NULL,
  `CompareWith` varchar(100) DEFAULT NULL,
  `Enabled` char(1) DEFAULT NULL,
  `UseAsLabel` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportmetadata`
--

LOCK TABLES `reportmetadata` WRITE;
/*!40000 ALTER TABLE `reportmetadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportmetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `UID` bigint(20) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `UserIdCreatedBy` varchar(10) DEFAULT NULL,
  `UserIdUpdatedBy` varchar(10) DEFAULT NULL,
  `CreationDateTime` datetime DEFAULT NULL,
  `UpdateDateTime` datetime DEFAULT NULL,
  `RecordVersion` int(11) DEFAULT NULL,
  `IsVoid` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (0,'red','10',NULL,NULL,NULL,NULL,NULL,NULL),(1,'RED','Toddler 1','child',NULL,'2012-04-04 21:16:01','2012-04-29 17:32:59',1,'N'),(2,'BLUE','Toddler 2','child',NULL,'2012-04-04 21:16:18','2012-04-29 17:33:17',1,'N'),(3,'YELLOW','Preschool 1','child','child','2012-04-29 17:18:56','2012-04-29 17:18:56',1,'N'),(4,'GREEN','Preschool 2','child','child','2012-04-29 17:19:11','2012-04-29 17:19:11',1,'N'),(5,'PURPLE','Babies','child','child','2012-04-29 17:33:37','2012-04-29 17:33:37',1,'N');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker`
--

DROP TABLE IF EXISTS `worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker` (
  `UID` bigint(20) NOT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `WLVL_Level` varchar(10) DEFAULT NULL,
  `UserIdCreatedBy` varchar(10) DEFAULT NULL,
  `UserIdUpdatedBy` varchar(10) DEFAULT NULL,
  `CreationDateTime` datetime DEFAULT NULL,
  `UpdateDateTime` datetime DEFAULT NULL,
  `RecordVersion` int(11) DEFAULT NULL,
  `IsVoid` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker`
--

LOCK TABLES `worker` WRITE;
/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` VALUES (1,'Katia','Machado','LVL1',NULL,NULL,NULL,NULL,NULL,NULL),(2,'Katia','Machado','LEVEL2','child','child','2012-04-08 09:36:56','2012-04-27 22:51:05',6,'N'),(3,'Daniel','Machado','LEVEL1','child','child','2012-04-08 09:37:09','2012-04-08 09:37:09',1,'N'),(4,'Kevin','Machado','LEVEL2','child','child','2012-04-08 09:37:16','2012-04-08 12:21:28',2,'N'),(5,'Arthur','M','LEVEL1','child','child','2012-04-08 09:37:25','2012-04-27 22:51:59',2,'N'),(6,'Joaquim','Ferraz','LEVEL1','child','child','2012-04-08 10:22:21','2012-04-08 10:22:21',1,'N'),(7,'Joaquim','Santos','LEVEL1','child','child','2012-04-25 15:38:24','2012-04-25 15:38:24',1,'N');
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workerroom`
--

DROP TABLE IF EXISTS `workerroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workerroom` (
  `UID` bigint(20) NOT NULL,
  `FKWorkerUID` bigint(20) DEFAULT NULL,
  `FKRoomUID` bigint(20) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `IsActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`UID`),
  KEY `FKN_Worker` (`FKWorkerUID`),
  KEY `FKN_Room` (`FKRoomUID`),
  CONSTRAINT `FKN_Room` FOREIGN KEY (`FKRoomUID`) REFERENCES `room` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKN_Worker` FOREIGN KEY (`FKWorkerUID`) REFERENCES `worker` (`UID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workerroom`
--

LOCK TABLES `workerroom` WRITE;
/*!40000 ALTER TABLE `workerroom` DISABLE KEYS */;
/*!40000 ALTER TABLE `workerroom` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-10-14 21:57:08
